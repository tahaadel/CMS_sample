<?php require_once('../../private/initialize.php'); ?>

<?php $page_title = 'Staff Menu'; ?>
<?php include('../../private/shared/staff_header.php'); ?>


<div class="container mt-5">
    <h2 class="pt-5 pb-2">Main Menu</h2>
    <div class="list-group">

        <a href="<?php echo 'http://localhost/linkedin/CMS/public/staff/subjects/index.php'; ?>" class="list-group-item list-group-item-action list-group-item-danger w-25">Subjects</a>
        <a href="<?php echo 'http://localhost/linkedin/CMS/public/staff/pages/index.php'; ?>" class="list-group-item list-group-item-action list-group-item-primary w-25">Pages</a>
    </div>
</div>




<?php include(SHARED_PATH . '/staff_footer.php'); ?>
