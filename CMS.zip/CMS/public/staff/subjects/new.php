<?php

require_once('../../../private/initialize.php');

if(is_post_request()) {

  $subject = [];

//    if(isset($_POST['menu_name']))
//    { $subject['menu_name'] = $_POST['menu_name']; }
//
//    if(isset($_POST['position']))
//    { $subject['position'] = $_POST['position']; }
//
//    if(isset($_POST['visible']))
//    { $subject['visible'] = $_POST['visible']; }

  $subject['menu_name'] = $_POST['menu_name'] ?? '';
  $subject['position'] = $_POST['position'] ?? '';
  $subject['visible'] = $_POST['visible'] ?? '';

  $result = insert_subject($subject);
  if($result === true) {
    $new_id = mysqli_insert_id($db);
    redirect_to(url_for('/staff/subjects/show.php?id=' . $new_id));
  } else {
    $errors = $result;
  }

} else {
  // display the blank form
    $subject_set = find_all_subjects();
    $subject_count = mysqli_num_rows($subject_set) + 1;
  $subject = [];
  $subject["menu_name"] = '';
  $subject["position"] = $subject_count;
  $subject["visible"] = '';
}


mysqli_free_result($subject_set);

?>

<?php $page_title = 'Create Subject'; ?>
<?php include('../../../private/staff_header.php'); ?>

<div class="container pt-3 mt-5">

    <h2>Create form</h2>
    <form action="<?php echo url_for('/staff/subjects/new.php'); ?>" method="post">
        <div class="form-group">
            <label for="menu_email">Menu Name:</label>
            <input type="text" class="form-control" id="email" placeholder="Enter Menu Name" value="<?php echo $subject['menu_name']; ?>" name="menu_name">
        </div>

        <div class="form-group">
            <label for="sel1">Select list (select one):</label>
            <select class="form-control" id="sel1" name="position">
                <?php
                for($i=1; $i <= $subject_count; $i++) {
                    echo "<option value=\"{$i}\"";
                    if($subject["position"] == $i) {
                        echo " selected";
                    }
                    echo ">{$i}</option>";
                }
                ?>
            </select>

        </div>

        <div class="form-group form-check">
            <label class="form-check-label">
                <input type="hidden" name="visible" value="0" />
                <input class="form-check-input" type="checkbox" name="visible"value="1"<?php if($subject['visible'] == "1") { echo " checked"; } ?> >Visible
            </label>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>




<?php include('../../../private/staff_footer.php'); ?>
