<?php
  ob_start(); // output buffering is turned on

  require_once('functions.php');
  require_once('database.php');


  $db = db_connect();
  $errors = [];

?>
