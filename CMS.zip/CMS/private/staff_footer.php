<footer>
  &copy; <?php echo date('Y'); ?> Test Form
</footer>





</body>
</html>

<?php
  db_disconnect($db);
?>
